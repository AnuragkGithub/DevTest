from django.contrib import admin

# Register your models here.
from .models import Dataset_2
from import_export.admin import ImportExportModelAdmin
admin.site.register(Dataset_2,ImportExportModelAdmin)
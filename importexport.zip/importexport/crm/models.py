from django.db import models

# Create your models here.
class Dataset_2(models.Model):
    Cust_State= models.CharField(max_length=150)
    